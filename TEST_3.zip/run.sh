#!/bin/bash

make clean
make

num=5

ipath="./in/in"
opath="./out/out"
param="./argument.txt"

post=".bin"

python3 set_tile.py

for i in $(seq $num)
do
	index=$((i-1))
	in="${ipath}${index}${post}"
	out="${opath}${index}${post}"

	./test $param $in $out 
done
