#!/bin/bash

import sys
import os
import numpy as np

def main():
	print("!!!!")

if __name__ == "__main__":
	sys.exit(main())
