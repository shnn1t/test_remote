#include "../inc/test.h"

void test(void *p0, void *p1) {
	st_thr * p = (st_thr *)p0;

	unsigned char * p_in = (unsigned char *)p->iaddr;
	unsigned char * p_out = (unsigned char *)p->oaddr;
	unsigned int s = p->size;

	int i = 0;
	for(; i < s; ++i) {
		p_out[i] = p_in[i];
	}

	return;
}

void test_preproc(const k_context_t *p_context) {
	return;
}

void test_postproc(const k_context_t *p_context) {
	return;
}

void test_kernel(const k_context_t *p_context, k_result_t *p_result) {
	st_thr st1;

	u32 size = p_context->p_tile_info->p_otile_info[0]->tile.size.w * p_context->p_tile_info->p_otile_info[0]->tile.size.h * p_context->p_tile_info->p_otile_info[0]->tile.size.d; 

	st1.iaddr = (unsigned long)p_context->p_tile_info->p_itile_info[0]->addr;
	st1.oaddr = (unsigned long)p_context->p_tile_info->p_otile_info[0]->addr;
	st1.size = size;

	test(&st1, "");

	return;
}
