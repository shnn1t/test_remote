#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../inc/data_types.h"
#include "../inc/test.h"

void context_dump(const k_context_t * p_context, const u32 num_input, const u32 num_output, const u32 num_temp) {
	int i;

	printf("num_input: %d, num_output: %d, num_temp: %d\n", num_input, num_output, num_temp);

	printf("====== in_info ======\n");
	for(i = 0; i < num_input; ++i) {
		printf("p_context->p_io_info->p_input[%d]->size.w = %ld\n", i, p_context->p_io_info->p_input[i]->size.w);
		printf("p_context->p_io_info->p_input[%d]->size.h = %ld\n", i, p_context->p_io_info->p_input[i]->size.h);
		printf("p_context->p_io_info->p_input[%d]->size.d = %ld\n", i, p_context->p_io_info->p_input[i]->size.d);
		printf("p_context->p_io_info->p_input[%d]->tile_size.w = %ld\n", i, p_context->p_io_info->p_input[i]->tile_size.w);
		printf("p_context->p_io_info->p_input[%d]->tile_size.h = %ld\n", i, p_context->p_io_info->p_input[i]->tile_size.h);
		printf("p_context->p_io_info->p_input[%d]->tile_size.d = %ld\n", i, p_context->p_io_info->p_input[i]->tile_size.d);
		printf("p_context->p_io_info->p_input[%d]->num_tile.w = %ld\n", i, p_context->p_io_info->p_input[i]->num_tile.w);
		printf("p_context->p_io_info->p_input[%d]->num_tile.h = %ld\n", i, p_context->p_io_info->p_input[i]->num_tile.h);
		printf("p_context->p_io_info->p_input[%d]->num_tile.d = %ld\n", i, p_context->p_io_info->p_input[i]->num_tile.d);
		printf("p_context->p_io_info->p_input[%d]->padding.l = %d\n", i, p_context->p_io_info->p_input[i]->padding.l);
		printf("p_context->p_io_info->p_input[%d]->padding.r = %d\n", i, p_context->p_io_info->p_input[i]->padding.r);
		printf("p_context->p_io_info->p_input[%d]->padding.t = %d\n", i, p_context->p_io_info->p_input[i]->padding.t);
		printf("p_context->p_io_info->p_input[%d]->padding.b = %d\n", i, p_context->p_io_info->p_input[i]->padding.b);
		printf("p_context->p_io_info->p_input[%d]->tile_dram_stride.w = %ld\n", i, p_context->p_io_info->p_input[i]->tile_dram_stride.w);
		printf("p_context->p_io_info->p_input[%d]->tile_dram_stride.h = %ld\n", i, p_context->p_io_info->p_input[i]->tile_dram_stride.h);
		printf("p_context->p_io_info->p_input[%d]->tile_dram_stride.d = %ld\n", i, p_context->p_io_info->p_input[i]->tile_dram_stride.d);
		printf("p_context->p_io_info->p_input[%d]->tile_vm_shape.w = %ld\n", i, p_context->p_io_info->p_input[i]->tile_vm_shape.w);
		printf("p_context->p_io_info->p_input[%d]->tile_vm_shape.h = %ld\n", i, p_context->p_io_info->p_input[i]->tile_vm_shape.h);
		printf("p_context->p_io_info->p_input[%d]->tile_vm_start_offset = %d\n", i, p_context->p_io_info->p_input[i]->tile_vm_start_offset);
	}
	printf("====== ======\n\n");
	
	printf("====== out_info ======\n");
	for(i = 0; i < num_output; ++i) {
		printf("p_context->p_io_info->p_output[%d]->size.w = %ld\n", i, p_context->p_io_info->p_output[i]->size.w);
		printf("p_context->p_io_info->p_output[%d]->size.h = %ld\n", i, p_context->p_io_info->p_output[i]->size.h);
		printf("p_context->p_io_info->p_output[%d]->size.d = %ld\n", i, p_context->p_io_info->p_output[i]->size.d);
		printf("p_context->p_io_info->p_output[%d]->tile_size.w = %ld\n", i, p_context->p_io_info->p_output[i]->tile_size.w);
		printf("p_context->p_io_info->p_output[%d]->tile_size.h = %ld\n", i, p_context->p_io_info->p_output[i]->tile_size.h);
		printf("p_context->p_io_info->p_output[%d]->tile_size.d = %ld\n", i, p_context->p_io_info->p_output[i]->tile_size.d);
		printf("p_context->p_io_info->p_output[%d]->num_tile.w = %ld\n", i, p_context->p_io_info->p_output[i]->num_tile.w);
		printf("p_context->p_io_info->p_output[%d]->num_tile.h = %ld\n", i, p_context->p_io_info->p_output[i]->num_tile.h);
		printf("p_context->p_io_info->p_output[%d]->num_tile.d = %ld\n", i, p_context->p_io_info->p_output[i]->num_tile.d);
		printf("p_context->p_io_info->p_output[%d]->tile_vm_shape.w = %ld\n", i, p_context->p_io_info->p_output[i]->tile_vm_shape.w);
		printf("p_context->p_io_info->p_output[%d]->tile_vm_shape.h = %ld\n", i, p_context->p_io_info->p_output[i]->tile_vm_shape.h);
		printf("p_context->p_io_info->p_output[%d]->tile_vm_start_offset = %d\n", i, p_context->p_io_info->p_output[i]->tile_vm_start_offset);
	}
	printf("====== ======\n\n");

	printf("====== temp_info ======\n");
	printf("p_context->p_vm_buf->numbuf = %d\n", p_context->p_vm_buf->num_buf);
	for(i = 0; i < num_temp; ++i) {
		printf("p_context->p_vm_buf->buf[%d].size  = %ld\n", i, p_context->p_vm_buf->buf[i].size);
	}
	printf("====== ======\n\n");

	printf("====== itile_info ======\n");
	for(i = 0; i < num_input; ++i) {
		printf("p_context->p_tile_info->p_itile_info[%d]->tile.size.w = %ld\n", i, p_context->p_tile_info->p_itile_info[i]->tile.size.w);
		printf("p_context->p_tile_info->p_itile_info[%d]->tile.size.h = %ld\n", i, p_context->p_tile_info->p_itile_info[i]->tile.size.h);
		printf("p_context->p_tile_info->p_itile_info[%d]->tile.size.d = %ld\n", i, p_context->p_tile_info->p_itile_info[i]->tile.size.d);
		printf("p_context->p_tile_info->p_itile_info[%d]->index.w = %ld\n", i, p_context->p_tile_info->p_itile_info[i]->index.w);
		printf("p_context->p_tile_info->p_itile_info[%d]->index.h = %ld\n", i, p_context->p_tile_info->p_itile_info[i]->index.h);
		printf("p_context->p_tile_info->p_itile_info[%d]->index.d = %ld\n", i, p_context->p_tile_info->p_itile_info[i]->index.d);
	}
	printf("====== ======\n\n");

	printf("====== otile_info ======\n");
	for(i = 0; i < num_output; ++i) {
		printf("p_context->p_tile_info->p_otile_info[%d]->tile.size.w = %ld\n", i, p_context->p_tile_info->p_otile_info[i]->tile.size.w);
		printf("p_context->p_tile_info->p_otile_info[%d]->tile.size.h = %ld\n", i, p_context->p_tile_info->p_otile_info[i]->tile.size.h);
		printf("p_context->p_tile_info->p_otile_info[%d]->tile.size.d = %ld\n", i, p_context->p_tile_info->p_otile_info[i]->tile.size.d);
		printf("p_context->p_tile_info->p_otile_info[%d]->index.w = %ld\n", i, p_context->p_tile_info->p_otile_info[i]->index.w);
		printf("p_context->p_tile_info->p_otile_info[%d]->index.h = %ld\n", i, p_context->p_tile_info->p_otile_info[i]->index.h);
		printf("p_context->p_tile_info->p_otile_info[%d]->index.d = %ld\n", i, p_context->p_tile_info->p_otile_info[i]->index.d);
	}
	printf("====== ======\n\n");

	printf("====== param_info ======\n");
	printf("====== ======\n\n");
	printf("\n");

	return;
}

int main(int argc, char **argv) {
	printf("\nargc: %d\n\n", argc);

	rewind(stdin);
	rewind(stdout);

	int i;

	char * ppath = argv[1];
	FILE *fp;
	fp = fopen(ppath, "rb");
	if(!fp) {
		printf("foe\n");
		return -1;
	}
	//freopen(ppath, "rb", stdin);
	u32 num_input = 0;
	u32 num_output = 0;
	u32 num_temp = 0;

	char buf[101];
	char *pbuf;
	pbuf = fgets(buf, 101, fp);

	pbuf = fgets(buf, 101, fp);
	num_input = atoi(pbuf);
	pbuf += 7;
	num_output = atoi(pbuf);
	pbuf += 7;
	num_temp = atoi(pbuf);
	
	// set kernel	
	ofi_kernel_func_t ofi_kernel_func;
	ofi_kernel_func.f_kernel = test_kernel;	
	ofi_kernel_func.f_preproc = test_preproc;	
	ofi_kernel_func.f_postproc = test_postproc;

	// set buffer
	k_context_t context;
	k_result_t result;

	io_infos_t io_infos;
	tile_infos_t tile_infos;
	vm_buf_t vm_buf;
	st_para param1;

	context.p_io_info = (const io_infos_t *)&io_infos;
	context.p_tile_info = (const tile_infos_t *)&tile_infos;
	context.p_para = (void *)&param1;
	context.p_vm_buf = (const vm_buf_t *)&vm_buf;

	input_info_t *input_info = (input_info_t *)malloc(num_input * sizeof(input_info_t));
	output_info_t *output_info = (output_info_t *)malloc(num_output * sizeof(output_info_t));

	for(i = 0; i < num_input; ++i) {
		io_infos.p_input[i] = (input_info_t *)&input_info[i];
	}

	for(i = 0; i < num_output; ++i) {
		io_infos.p_output[i] = (output_info_t *)&output_info[i];
	}

	tile_info_t *itile_info	= (tile_info_t *)malloc(num_input * sizeof(tile_info_t));
	tile_info_t *otile_info	= (tile_info_t *)malloc(num_output * sizeof(tile_info_t));

	for(i = 0; i < num_input; ++i) {
		tile_infos.p_itile_info[i] = (tile_info_t *)&itile_info[i];
	}

	for(i = 0; i < num_output; ++i) {
		tile_infos.p_otile_info[i] = (tile_info_t *)&otile_info[i];
	}

	// set value
	for(i = 0; i < num_input; ++i) {
		pbuf = fgets(buf, 100, fp);

		//scanf("%ld %ld %ld", &input_info[i].size.w, &input_info[i].size.h, &input_info[i].size.d);
		pbuf = fgets(buf, 100, fp);
		input_info[i].size.w = atoi(pbuf);
		pbuf += 7;
		input_info[i].size.h = atoi(pbuf);
		pbuf += 7;
		input_info[i].size.d = atoi(pbuf);

		//scanf("%ld %ld %ld", &input_info[i].tile_size.w, &input_info[i].tile_size.h, &input_info[i].tile_size.d);
		pbuf = fgets(buf, 100, fp);
		input_info[i].tile_size.w = atoi(pbuf);
		pbuf += 7;
		input_info[i].tile_size.h = atoi(pbuf);
		pbuf += 7;
		input_info[i].tile_size.d = atoi(pbuf);

		u32 p, l, r, t, b;
		//scanf("%d %d %d %d", &l, &r, &t, &b);
		pbuf = fgets(buf, 100, fp);
		l = atoi(pbuf);
		pbuf += 7;
		r = atoi(pbuf);
		pbuf += 7;
		t = atoi(pbuf);
		pbuf += 7;
		b = atoi(pbuf);

		p = (l << 24) | (r << 16) | (t << 8) | b;
		//input_info[i].padding = p; !

		//scanf("%ld %ld %ld", &input_info[i].tile_dram_stride.w, &input_info[i].tile_dram_stride.h, &input_info[i].tile_dram_stride.d);
		pbuf = fgets(buf, 100, fp);
		input_info[i].tile_dram_stride.w = atoi(pbuf);
		pbuf += 7;
		input_info[i].tile_dram_stride.h = atoi(pbuf);
		pbuf += 7;
		input_info[i].tile_dram_stride.d = atoi(pbuf);

		//scanf("%ld %ld", &input_info[i].tile_vm_shape.w, &input_info[i].tile_vm_shape.h);
		pbuf = fgets(buf, 100, fp);
		input_info[i].tile_vm_shape.w = atoi(pbuf);
		pbuf += 7;
		input_info[i].tile_vm_shape.h = atoi(pbuf);

		//scanf("%d", &input_info[i].tile_vm_start_offset);
		pbuf = fgets(buf, 100, fp);
		input_info[i].tile_vm_start_offset = atoi(pbuf);
	}

	for(i = 0; i < num_output; ++i) {
		pbuf = fgets(buf, 100, fp);

		//scanf("%ld %ld %ld", &output_info[i].size.w, &output_info[i].size.h, &output_info[i].size.d);
		pbuf = fgets(buf, 100, fp);
		output_info[i].size.w = atoi(pbuf);
		pbuf += 7;
		output_info[i].size.h = atoi(pbuf);
		pbuf += 7;
		output_info[i].size.d = atoi(pbuf);

		//scanf("%ld %ld %ld", &output_info[i].tile_size.w, &output_info[i].tile_size.h, &output_info[i].tile_size.d);
		pbuf = fgets(buf, 100, fp);
		output_info[i].tile_size.w = atoi(pbuf);
		pbuf += 7;
		output_info[i].tile_size.h = atoi(pbuf);
		pbuf += 7;
		output_info[i].tile_size.d = atoi(pbuf);

		//scanf("%ld %ld", &output_info[i].tile_vm_shape.w, &output_info[i].tile_vm_shape.h);
		pbuf = fgets(buf, 100, fp);
		output_info[i].tile_vm_shape.w = atoi(pbuf);
		pbuf += 7;
		output_info[i].tile_vm_shape.h = atoi(pbuf);

		//scanf("%d", &output_info[i].tile_vm_start_offset);
		pbuf = fgets(buf, 100, fp);
		output_info[i].tile_vm_start_offset = atoi(pbuf);
	}

	vm_buf.num_buf = num_temp;
	pbuf = fgets(buf, 100, fp);

	pbuf = fgets(buf, 100, fp);
	for(i = 0; i < num_temp; ++i) {
		//scanf("%ld", &vm_buf.buf[i].size);
		vm_buf.buf[i].size = atoi(pbuf);
		pbuf += 7;
	}

	// calc num_tile, cur_tile_size, tile_index !
	for(i = 0; i < num_input; ++i) {
		itile_info[i].tile.size.w = 100;
		itile_info[i].tile.size.h = 1;
		itile_info[i].tile.size.d = 1;
	}

	for(i = 0; i < num_input; ++i) {
		otile_info[i].tile.size.w = 100;
		otile_info[i].tile.size.h = 1;
		otile_info[i].tile.size.d = 1;
	}

#if 1
	// print context
	context_dump((const k_context_t *)&context, num_input, num_output, num_temp);
#endif

	// alloc buffer
	unsigned char **ibuf = (unsigned char **)malloc(num_input * sizeof(unsigned char *));
	for(i = 0; i < num_input; ++i) {
		u32 size = input_info[i].tile_size.w * input_info[i].tile_size.h * input_info[i].tile_size.d; 
		ibuf[i] = (unsigned char *)malloc(size * sizeof(ibuf[i][0]));

		itile_info[i].addr = (size_t)ibuf[i];
	}

	unsigned char **obuf = (unsigned char **)malloc(num_output * sizeof(unsigned char *));
	for(i = 0; i < num_output; ++i) {
		u32 size = output_info[i].tile_size.w * output_info[i].tile_size.h * output_info[i].tile_size.d; 
		obuf[i] = (unsigned char *)malloc(size * sizeof(obuf[i][0]));

		otile_info[i].addr = (size_t)obuf[i];
	}

	unsigned char **tbuf = (unsigned char **)malloc(num_temp * sizeof(unsigned char *));
	for(i = 0; i < num_temp; ++i) {
		u32 size = vm_buf.buf[i].size;

		tbuf[i] = (unsigned char *)malloc(size * sizeof(tbuf[i][0]));

		vm_buf.buf[i].addr = (size_t)tbuf[i];
	}

	// read tile !
	for(i = 0; i < num_input; ++i) {
		u32 size = itile_info[i].tile.size.w * itile_info[i].tile.size.h * itile_info[i].tile.size.d; 
		char * ipath = argv[i+2];
		fp = fopen(ipath, "rb");
		if(fp) {
			fread(ibuf[i], sizeof(ibuf[i][0]), size, fp);
			fclose(fp);
		} else {
			printf("ifoe[%d]\n", i);
		}
	}

	rewind(stdin);
	rewind(stdout);

	// run
	ofi_kernel_func.f_preproc(&context);	
	ofi_kernel_func.f_kernel(&context, &result);	
	ofi_kernel_func.f_postproc(&context);

	// write tile !
	for(i = 0; i < num_output; ++i) {
		u32 size = otile_info[i].tile.size.w * otile_info[i].tile.size.h * otile_info[i].tile.size.d; 
		char * opath = argv[i+2+num_input];
		fp = fopen(opath, "wb");
		if(fp) {
			fwrite(obuf[i], sizeof(obuf[i][0]), size, fp);
			fclose(fp);
		} else {
			printf("ofoe[%d]\n", i);
		}
	}

	// free buffer
	free(input_info);
	free(output_info);
	
	free(itile_info);
	free(otile_info);

	for(i = 0; i < num_input; ++i) {
		free(ibuf[i]);
	}
	free(ibuf);

	for(i = 0; i < num_output; ++i) {
		free(obuf[i]);
	}
	free(obuf);

	for(i = 0; i < num_temp; ++i) {
		free(tbuf[i]);
	}
	free(tbuf);

	return 0;
}
