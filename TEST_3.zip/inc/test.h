#ifndef __TEST__
#define __TEST__

#include "data_types.h"

typedef struct {
	unsigned long iaddr;
	unsigned long oaddr;
	unsigned int size;
} st_thr;

typedef struct {
	int a;
	int b[5];
} st_para;

void test_preproc(const k_context_t *);
void test_postproc(const k_context_t *);
void test_kernel(const k_context_t *, k_result_t *); 

#endif // __TEST__
