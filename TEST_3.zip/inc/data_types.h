#ifndef __DATA_TYPES_H__
#define __DATA_TYPES_H__

#define MAX_NUM (8)
#define MAX_NUM_BUF (8)

typedef char s8;
typedef unsigned char u8;
typedef short s16;
typedef unsigned short u16;
typedef int s32;
typedef unsigned int u32;

typedef unsigned long size_t;

typedef size_t num_t;
typedef size_t index_t;

typedef struct {
	size_t w;
	size_t h;
	size_t d;
} size3d_t;

typedef struct {
	size_t w;
	size_t h;
} size2d_t;

typedef struct {
	index_t w;
	index_t h;
	index_t d;
} index3d_t;

typedef struct {
	index_t w;
	index_t h;
} index2d_t;

typedef struct {
	num_t w;
	num_t h;
	num_t d;
} num3d_t;

typedef struct {
	num_t w;
	num_t h;
} num2d_t;

typedef struct {
	size_t x0;
	size_t y0;
	size_t x1;
	size_t y1;
} rec_t;

typedef struct {
	u32 l : 8;
	u32 r : 8;
	u32 t : 8;
	u32 b : 8;
} padding_t;

typedef struct {
	size_t w;
	size_t h;
	size_t d;
} stride3d_t;

typedef struct {
	size_t w;
	size_t h;
} stride2d_t;

typedef struct {
	size_t addr;
	size_t size;
} buf_t;

typedef struct {
	u32 num_buf;
	buf_t buf[MAX_NUM_BUF];
} vm_buf_t;

typedef struct {
	size3d_t size;
	size2d_t offset;
} tile_t;

typedef struct {
	tile_t tile;
	index3d_t index;
	size_t addr;
} tile_info_t;

typedef struct {
	tile_info_t *p_itile_info[MAX_NUM_BUF];
	tile_info_t *p_otile_info[MAX_NUM_BUF];
} tile_infos_t;

typedef struct {
	/*Do not use*/
} tile_cti_t;

typedef struct {
	size3d_t size;
	size3d_t tile_size;
	num3d_t num_tile;
	padding_t padding;
	stride3d_t tile_dram_stride;
	size2d_t tile_vm_shape;
	u32 tile_vm_start_offset;
} input_info_t;

typedef struct {
	size3d_t size;
	size3d_t tile_size;
	num3d_t num_tile;
	size2d_t tile_vm_shape;
	u32 tile_vm_start_offset;
} output_info_t;

typedef struct {
	u32 input_valid_map;
	u32 output_valid_map;
	input_info_t *p_input[MAX_NUM];
	output_info_t *p_output[MAX_NUM];
} io_infos_t;

typedef struct {
	const io_infos_t *p_io_info;
	const tile_infos_t *p_tile_info;
	const void *p_para;
	const vm_buf_t *p_vm_buf;
} k_context_t;

typedef struct {
	tile_cti_t *p_tile_cti;
} k_result_t;

typedef void (*kernel_f)(const k_context_t *p_context, k_result_t *p_result);
typedef void (*preproc_f)(const k_context_t *p_context);
typedef void (*postproc_f)(const k_context_t *p_context);

typedef struct {
	kernel_f f_kernel;
	preproc_f f_preproc;
	postproc_f f_postproc;
} ofi_kernel_func_t;

#endif // __DATA_TYPES_H__
